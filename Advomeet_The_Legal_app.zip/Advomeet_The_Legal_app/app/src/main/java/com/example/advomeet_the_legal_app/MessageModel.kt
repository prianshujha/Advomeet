package com.example.advomeet_the_legal_app

data class MessageModel(
    var message:String?="",
    var senderid:String?="",
    var timestamp:Long?=0,
)
