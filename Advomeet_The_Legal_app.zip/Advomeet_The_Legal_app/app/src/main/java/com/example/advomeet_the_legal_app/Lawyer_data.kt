package com.example.advomeet_the_legal_app

data class Lawyer_data(val image:Int,val fname:String,val lname:String,val phoneno:String)
