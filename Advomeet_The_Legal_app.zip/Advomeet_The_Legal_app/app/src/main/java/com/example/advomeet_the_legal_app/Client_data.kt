package com.example.advomeet_the_legal_app

data class Client_data(val fname:String?=null,val lname:String?=null,val phoneno1:String?=null,val phoneno2:String?=null,val city:String?=null,val district:String?=null,val state:String?=null,val pincode:Int?=null,val gender:String?=null)
